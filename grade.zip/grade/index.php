<?php
// Read the JSON file
$json_file = file_get_contents('student.json');
$students = json_decode($json_file, true);

// Function to calculate grade
function calculateGrade($score) {
    if ($score >= 80) return 'A';
    if ($score >= 70) return 'B';
    if ($score >= 60) return 'C';
    if ($score >= 50) return 'D';
    return 'F';
}

// Sort students by score in descending order
usort($students, function($a, $b) {
    return $b['score'] - $a['score'];
});

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Grades</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Student Grades</h1>
    <table>
        <tr>
            <th>Name</th>
            <th>Score</th>
            <th>Grade</th>
        </tr>
        <?php foreach ($students as $student): ?>
        <tr>
            <td><?php echo htmlspecialchars($student['name']); ?></td>
            <td><?php echo $student['score']; ?></td>
            <td><?php echo calculateGrade($student['score']); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>